<footer class="footer">
	<div class="container mt-5">
		<div class="row ">
			<div class="col-md-12 mt-5 text-center">
			    <img src="../assets/images/merry-christmas.png" class="img-fluid" alt="Merry Christmas">
			</div>
			<div class="col-md-12 text-center mt-5">
				<h6 class=""><?php echo $lang['SANTA_BLOG']; ?> 🎅 © <?php echo date("Y"); ?></a></h6>
			</div>
		</div>
	</div>
</footer>

    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/main.js"></script>
	
</body>
</html>
