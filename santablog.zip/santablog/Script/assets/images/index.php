<?php
//I love to keep quiet in directories like this! 
?>